-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2023 at 03:02 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resto_platform`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `Id` int(11) NOT NULL,
  `restaurant_id` int(11) DEFAULT NULL,
  `street` varchar(100) NOT NULL,
  `region` varchar(50) NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`Id`, `restaurant_id`, `street`, `region`, `state`) VALUES
(8, 28, 'زكي باشا', 'الاسماعيلية', 3),
(11, 30, 'الجمهورية', 'اسماعيلة', 3),
(12, 1, 'جانب دير المحبة', 'العزيزية', 3),
(15, 49, 'بستان كل آب', 'باب فرج', 3),
(16, 50, 'جانب جامع الصديق', 'الجميلية', 3),
(17, 51, 'أخر خط الترام', 'الجميلية', 3),
(18, 52, 'حي الشهداء', 'حلب الجديد', 3),
(19, 53, 'جانب جامع الصديق', 'الجميلية', 5),
(20, 53, 'جانب جامع الصديق', 'الجميلية', 3),
(42, 72, 'مقابل جامع زكي باشا', 'الإسماعيلية', 3),
(47, 72, 'أرينا مول', 'الحمدانية جنوبي', 3),
(52, 52, 'أمام مشفى الطب العربي', 'الخالدية', 3),
(53, 81, 'منشأة الباسل', 'الموكامبو', 3),
(54, 81, 'جانب مسبح الاتحاد', 'الشهباء', 3),
(55, 82, 'العزيزية', 'العزيزية', 3),
(56, 83, 'بجانب كنيسة مريمية', 'القيمرية', 1),
(60, 89, 'fdvd', 'dfv', 7),
(61, 90, 'hh', 'hh', 3),
(67, 95, 'جانب زكي باشا', 'الإسماعيلية', 3);

-- --------------------------------------------------------

--
-- Table structure for table `advert`
--

CREATE TABLE `advert` (
  `id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `ad_type` int(11) NOT NULL,
  `caption` varchar(500) NOT NULL,
  `media` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advert`
--

INSERT INTO `advert` (`id`, `restaurant_id`, `ad_type`, `caption`, `media`, `created_at`, `updated_at`) VALUES
(1, 72, 2, 'ترقبوا الوجبة الجديدة...!!', '', '2023-05-15 23:28:55', '2023-06-09 13:12:43'),
(5, 72, 1, 'زعيم تشيكن... أول مطعم في حلب يقدم وجبات و مأكولات بتوابل و نكهات مميزة ...لك التجربة..', '72_557274_الزعيم_n.jpg', '2023-05-17 10:55:34', '2023-06-09 13:13:23'),
(22, 72, 1, 'اعتبارا\" من يوم الجمعة 2 / 6 / 2023\r\nزعيم تشيكن يبدأ بتقديم بروستد الزعيم بالتوابل و النكهة الخاصة \r\nتوصيل مجاني من فرع حلب الجديدة \r\nلا تتردد ولا تحتار ... الزعيم تشيكن أحسن اختيار.', '72_486970_2الزعيم_n.jpg,72_586678_الزعيم_n.jpg', '2023-06-09 10:45:53', '2023-06-09 10:45:53'),
(26, 72, 4, 'دعوة لإفتتاح الفرع الجديد في أرينا مول - حلب الجديدة.\r\nو بمناسبة الافتتاح ستبدأ خدمة توصيل الطلبات الى المناطق المحيطة بالفرع الجديد مجانا\"\r\nالزعيم تشيكن ...أطيب تشيكن\r\nأرينا مول : حلب الجديدة جنوبي - دوار المتنبي - جمعية.', '72_407725_images.jpg', '2023-06-09 13:25:16', '2023-06-09 13:42:22'),
(27, 72, 5, 'بوكس طلاب التاسع والبكالوريا \r\nنعلمكم عن إستعداد سلسلة مطاعم الزعيم تشيكن لتقديم وجبات طلاب الشهادة الإعدادية و الثانوية القادمين من خارج محافظة حلب عبر الجمعيات مع ضمان تقديم ألذ الوجبات من أفضل المكونات وأنسب الأسعار وفق قواعد السلامة الغذائية حفاظاً على سلامة أبناءنا الطلاب \r\nالزعيم تشيكن ... أطيب تشيكن', '72_282093_347135045_816578350041887_4907811551970609660_n.jpg,72_988275_347633859_783641309963164_8557826015746277581_n.jpg,72_412032_347548004_1445743002908225_2178069437260768586_n.jpg', '2023-06-09 13:48:42', '2023-06-09 13:48:42'),
(28, 72, 1, 'نرحب بإستقبالكم في الفرع الأول بالإسماعيلية و الفرع الثاني في الأرينا مول بحلب الجديدة.\r\nفروج مشوي بأطيب تبلة في حلب - شاورما ع الفحم - شاورما لحم - وجبات غربية - بيتزا \r\nزعيم تشيكن ... أطيب تشيكن ...', '72_936710_347134258_206252855103397_8870245718428113066_n.jpg', '2023-06-09 13:50:32', '2023-06-09 13:50:32'),
(29, 81, 4, 'لا الرحلة ابتدأت ولا الدرب انتهى.\"\r\nمهما كتبنا من عباراتٍ فلن نجد أصدق من قوله تعالى : \"وَآخِرُ دَعْوَاهُمْ أَن الْحَمْدُ لله رَبِّ الْعَالَمِينَ\" ????????\r\nبعونه تعالى تم افتتاح فرعنا الجديد من سلسله مطاعم تيك تك بحلته الجديده...', '81_435377_postn.jpg', '2023-07-19 22:57:09', '2023-07-19 22:57:09'),
(30, 72, 2, 'البانيه صارت بـ 25000 ل.س فقط...', '72_855622_باينيهاتn.jpg', '2023-07-30 15:23:24', '2023-08-16 20:46:54');

-- --------------------------------------------------------

--
-- Table structure for table `ad_comment`
--

CREATE TABLE `ad_comment` (
  `id` int(11) NOT NULL,
  `advert_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `content` varchar(150) NOT NULL,
  `reply` varchar(150) DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL,
  `comment_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ad_comment`
--

INSERT INTO `ad_comment` (`id`, `advert_id`, `customer_id`, `content`, `reply`, `reply_date`, `comment_date`) VALUES
(2, 1, 1, 'الله الموفق', '', '2023-06-09 11:15:47', '2023-06-09 09:10:24'),
(4, 5, 29, 'الزعيم نعم الاختيار', '', '2023-06-09 13:10:17', '2023-06-09 09:53:19'),
(5, 22, 1, 'رقم التواصل؟', 'جميع المعلومات موجودة في البروفايل', '2023-06-09 17:53:03', '2023-06-09 17:22:26'),
(6, 22, 31, 'سعر البروستد؟', NULL, NULL, '2023-06-09 17:23:47'),
(46, 30, 1, 'ghvh', NULL, NULL, '2023-08-22 11:50:54');

-- --------------------------------------------------------

--
-- Table structure for table `ad_react`
--

CREATE TABLE `ad_react` (
  `id` int(11) NOT NULL,
  `advert_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `react_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ad_react`
--

INSERT INTO `ad_react` (`id`, `advert_id`, `customer_id`, `react_id`, `created_at`) VALUES
(1, 1, 1, 4, '2023-06-09 08:08:30'),
(2, 1, 31, 2, '2023-06-09 08:24:10'),
(4, 5, 31, 2, '2023-06-09 09:45:26'),
(7, 22, 1, 2, '2023-06-23 12:05:20'),
(12, 28, 1, 1, '2023-06-23 12:13:11'),
(13, 5, 1, 3, '2023-06-23 12:15:37'),
(16, 29, 1, 2, '2023-08-13 12:18:49'),
(17, 30, 1, 2, '2023-08-16 13:32:52');

-- --------------------------------------------------------

--
-- Table structure for table `ad_type`
--

CREATE TABLE `ad_type` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ad_type`
--

INSERT INTO `ad_type` (`id`, `name`) VALUES
(1, 'إعلان للمطعم'),
(2, 'إعلان لوجبة'),
(3, 'إعلان لعرض على وجبة'),
(4, 'إعلان لفرع جديد'),
(5, 'إعلان لخدمة جديدة');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `add_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `customer_id`, `recipe_id`, `quantity`, `add_date`) VALUES
(29, 31, 20, 1, '2023-06-15 08:27:16'),
(30, 31, 29, 1, '2023-06-15 08:27:31'),
(31, 31, 27, 1, '2023-06-15 08:27:35'),
(74, 1, 33, 1, '2023-08-22 11:55:51'),
(76, 1, 24, 2, '2023-08-22 11:55:57');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` char(10) NOT NULL,
  `password` varchar(150) NOT NULL,
  `image` varchar(250) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` date NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL,
  `verify_token` varchar(60) NOT NULL,
  `account_status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `phone`, `password`, `image`, `is_admin`, `created_at`, `address`, `verify_token`, `account_status`) VALUES
(1, 'Ahmed Mohsen', 'ahmed@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '1_879434_Images That Could Be Album Covers on Twitter.jpg', 0, '2023-03-25', 'حلب، الاسماعيلية، مقابل مشفى لويس', '36a4e3da49eef7eac5759791d4431f3f', 1),
(23, 'amiking1989', 'resto@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 1, '2023-05-18', '', '868a350ad2a3c592f4a403f013febae4', 1),
(24, 'Ahmed', 'ahmed17@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(25, 'Manal', 'manal@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(26, 'Rami', 'rami@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(27, 'Abdoullah', 'abdoullah@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(28, 'Jamal', 'jamal@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(29, 'Hamzah', 'hamzah@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(30, 'Hoseen', 'hoseen@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(31, 'Ali Al-Ahmad', 'ali@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-06-02', '', '', 1),
(32, 'Kamal Ali', 'Kamal@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 1),
(33, 'Sami Ahmed', 'sami@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 1),
(34, 'Daoud Deep', 'daoud@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 0),
(35, 'Ahmed Ahmed', 'aa2000@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 1),
(36, 'Zaid Homsi', 'zaid@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 1),
(37, 'Omar Kurdi', 'omar@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 0),
(38, 'Asmaa Ali', 'asmaa@gmail.com', '0991234567', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', 0, '2023-07-20', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `restaurant_id`, `name`, `description`, `image`, `is_default`) VALUES
(1, 72, 'وجبات أخرى', '', '', 1),
(2, 49, 'وجبات أخرى', '', '', 1),
(7, 72, 'مقبلات', 'وجبات خفيفة', '72_742162_arraimg8.jpg', 0),
(8, 72, 'وجبات الشاورما', 'جميع أنواع الشاورما', '72_160388_شاورما وكفتةn.jpg', 0),
(21, 72, 'وجبات غربية', 'تشمل جميع الوجبات الغربية مثل سبايسي، ناغيت، بروستد.. ', '72_398071_west meals menu.jpg', 0),
(22, 49, 'مشاوي حلبية', 'مشاوي مشكلة..', '49_529146_66314888_361089411260683_841749380254924800_n.jpg', 0),
(23, 49, 'طبخات حلبية', 'الأكل الحلبي الأصلي، كبب محاشي لحمة بكرز..', '49_87926_347400072_3351864661792248_7834975995686174387_n.jpg', 0),
(24, 72, 'صندويش', '', '72_579789_two-fresh-submarine-sandwiches-ham-260nw-497930494.webp', 0),
(25, 52, 'وجبات أخرى', '', '', 1),
(26, 82, 'حلويات', 'تشكيلة متنوعة من أشهى وألذ الحلويات', '82_312228_2018-10-16.jpg', 0),
(27, 82, 'أكل حلبي', 'الأكل المميز بالنكهة الحلبية', '82_662582_unnamed.jpg', 0),
(28, 81, 'وجبات أخرى', '', '', 1),
(29, 83, 'وجبات أخرى', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_`
--

CREATE TABLE `order_` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `order_status` int(11) DEFAULT NULL,
  `phone` char(10) NOT NULL,
  `notes` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_`
--

INSERT INTO `order_` (`id`, `customer_id`, `order_date`, `address`, `name`, `order_status`, `phone`, `notes`) VALUES
(15, 1, '2023-05-01 12:20:00', 'حلب، الاسماعيلية، جامع زكي باشا', 'Ahmed Mohsen', 5, '0992345678', ''),
(16, 27, '2023-08-10 10:25:15', 'حلب الاسماعيلية جانب زكي باشا', 'Abdoullah', 1, '0992345678', ''),
(17, 28, '2023-06-02 10:28:29', 'حلب الاسماعيلية جانب زكي باشا', 'Jamal', 5, '0992345678', ''),
(18, 29, '2023-04-04 10:29:58', 'حلب الاسماعيلية جانب زكي باشا', 'Hamzah', 5, '0992345678', ''),
(19, 29, '2023-05-02 10:34:45', 'حلب الاسماعيلية جانب زكي باشا', 'Hamzah', 5, '0992345678', ''),
(20, 1, '2023-06-13 13:17:15', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 5, '0992345678', ''),
(25, 1, '2023-07-15 23:21:03', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 4, '0992345678', ''),
(26, 24, '2023-07-16 16:29:26', 'المرديان، شارع ورديشان', 'Ahmed', 1, '0992345678', ''),
(27, 24, '2023-07-16 16:30:15', 'المرديان، شارع ورديشان', 'Ahmed', 6, '0992345678', ''),
(29, 1, '2023-07-30 13:30:07', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 2, '0992345678', ''),
(32, 1, '2023-08-14 13:09:33', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 1, '0992345678', ''),
(33, 1, '2023-08-16 13:25:24', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 1, '0991234567', ''),
(34, 1, '2023-08-16 14:26:44', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 2, '0991234567', ''),
(36, 1, '2023-08-17 09:34:19', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 2, '0991234567', ''),
(37, 1, '2023-08-17 09:34:44', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 1, '0991234567', ''),
(38, 1, '2023-08-22 11:56:12', 'حلب، الاسماعيلية، مقابل مشفى لويس', 'Ahmed Mohsen', 2, '0991234567', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`id`, `order_id`, `recipe_id`, `quantity`) VALUES
(16, 15, 3, 1),
(17, 15, 2, 1),
(18, 16, 2, 2),
(19, 16, 3, 1),
(20, 17, 2, 4),
(21, 17, 3, 2),
(22, 18, 1, 3),
(23, 18, 2, 2),
(24, 19, 1, 1),
(25, 20, 29, 2),
(26, 20, 27, 1),
(30, 25, 25, 1),
(31, 25, 29, 1),
(32, 26, 19, 1),
(33, 27, 29, 1),
(34, 27, 2, 1),
(37, 29, 33, 1),
(40, 32, 22, 4),
(41, 33, 34, 2),
(42, 34, 29, 1),
(44, 36, 28, 3),
(45, 36, 2, 1),
(46, 36, 29, 1),
(47, 37, 21, 1),
(48, 37, 22, 1),
(49, 38, 25, 1),
(50, 38, 29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`id`, `status`) VALUES
(1, 'معلق'),
(2, 'مقبول'),
(3, 'جاهز'),
(4, 'مرفوض'),
(5, 'مُسلم'),
(6, 'ملغي');

-- --------------------------------------------------------

--
-- Table structure for table `react`
--

CREATE TABLE `react` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `react`
--

INSERT INTO `react` (`id`, `name`, `image`) VALUES
(1, 'أحببته', 'heart.png'),
(2, 'أعجبني', 'like.png'),
(3, 'نااار', 'fire.png'),
(4, 'لذيذ', 'yemy.png'),
(5, 'أحزنني', 'sad-face.png');

-- --------------------------------------------------------

--
-- Table structure for table `recipe`
--

CREATE TABLE `recipe` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `discount_price` int(11) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  `categories` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recipe`
--

INSERT INTO `recipe` (`id`, `menu_id`, `name`, `description`, `price`, `discount_price`, `image`, `availability`, `created_at`, `updated_at`, `categories`) VALUES
(1, 21, 'وجبة تشكن برغر', 'برغر بدجاج', 23000, NULL, '72_366219_وجبة برغر دجاج-1.jpg', 1, '2023-05-03 05:46:36', '2023-06-05 10:28:55', 'برغر،برغر دجاج'),
(2, 21, 'وجبة بيف برغر', 'برغر بلحمة', 28000, NULL, '72_351179_phoimg31.jpg', 1, '2023-05-03 06:18:03', '2023-06-05 10:25:51', 'برغر،برغر لحمة'),
(3, 21, 'وجبة ناغيت', 'قطع فروج بروستد بتتبيلة الناغيت', 22000, NULL, '72_923578_ناغيت.jpg', 1, '2023-05-03 06:35:15', '2023-06-05 10:24:55', 'فروج،ناغيت،وجبة'),
(9, 7, 'وجبة سبايسي', 'فروج بروستد مع صوص السبايسي', 25000, NULL, '72_936281_سبايسيn.jpg', 1, '2023-05-07 19:25:56', '2023-06-05 10:22:22', 'سبايسي،وجبة،فروج'),
(19, 22, 'فروج مشوي', 'فروجة مشوية عالفحم مع سلطة وحمض وثوم(صلصه) وكريم ثوم  وخبز محمرة', 44000, NULL, '49_889488_346311844_979812329683135_1803285737456671309_n.jpg', 1, '2023-06-11 13:53:17', '2023-06-11 13:53:17', 'مشوي،فروج،فروجة،مشوية،عالفحم'),
(20, 22, 'كباب فروج', 'كيلو كباب فروج مع بصل مشوي وبندورة مشوية وخبز انطاكلي وجاط سلطة', 44000, NULL, '49_805398_347102907_198641609676586_9017459667598623545_n.jpg', 1, '2023-06-11 13:54:54', '2023-06-11 13:55:48', 'كباب،فروج،مشوي،خبز انطاكلي'),
(21, 23, 'لحمة بكرز', 'كيلو لحمة بكرز', 160000, NULL, '49_867032_331762048_1109931530402753_8785920680433380143_n.jpg', 1, '2023-06-11 13:57:27', '2023-06-11 13:57:27', 'لحمة بكرز،كرز،لحمة'),
(22, 22, 'كباب مع كماية', 'كباب مع كماية', 110000, NULL, '49_151551_335919180_737172744566329_5373024842949803758_n.jpg', 1, '2023-06-11 13:59:52', '2023-06-11 13:59:52', 'كباب،كما،كماية'),
(23, 23, 'منسف فريكة', 'منسف الفريكة ورز مع لحم الغنم لشخص', 30000, NULL, '49_84814_324597851_3469547686649502_7337589619932091759_n.jpg', 1, '2023-06-11 14:03:57', '2023-06-11 14:03:57', 'فريكة،رز،لحم،لشخص'),
(24, 23, 'صينية لحمة', 'صينية لحمة بالصينية مع البندورة (بالفرن )', 40000, NULL, '49_307992_321899788_3498848100440113_6410353649820418171_n.jpg', 1, '2023-06-11 14:08:40', '2023-06-11 14:08:40', 'صينية،لحمة،بالفرن'),
(25, 8, 'شاورما التركية ', 'وجبة الشاورما التركية ', 25000, NULL, '72_861600_352685691_640124008141952_344505957379762846_n.jpg', 0, '2023-06-11 14:11:53', '2023-06-11 14:27:42', 'شاورما،تركية'),
(26, 21, 'بروستد الزعيم', 'كيلو من بروستد الزعيم بالتوابل و النكهة الخاصة ', 50000, NULL, '72_827079_350636504_800570938305795_406913681436102493_n.jpg', 1, '2023-06-11 14:14:17', '2023-08-22 11:58:47', 'بروستد،الزعيم،سماهر'),
(27, 1, 'فروح مشوي', 'فروج مشوي بأطيب تبلة في حلب', 50000, NULL, '72_633522_347134258_206252855103397_8870245718428113066_n (1).jpg', 1, '2023-06-11 14:16:44', '2023-06-11 14:16:44', 'فروج مشوي،مشوي'),
(28, 8, 'منسف الفروج المشوي', 'منسف الفروج المشوي بطريقة الزعيم تشيكن مع البطاطا و الثوم و المكسرات ', 65000, NULL, '72_340926_342734855_6142214719200322_7008293414900942787_n.jpg', 1, '2023-08-08 00:00:00', '2023-08-17 09:43:22', 'منسف،مشوي،فروج،الزعيم،وجبات عربية معلوماتية 5'),
(29, 24, 'شاورما لحم', 'صندويش شاورما لحم الغنم المميزة بالنكهة اللذيذة', 19000, 17500, '72_283499_طريقة-تتبيل-شاورما-اللحمة.jpg', 1, '2023-06-11 14:24:45', '2023-06-11 14:27:24', 'شاورما لحم،لحم'),
(30, 24, 'شاورما على الفحم', 'صندويشة شاورما على الفحم', 12000, NULL, '72_16213_336157345_532311435479414_1586951403277011510_n.jpg', 1, '2023-06-11 14:27:06', '2023-06-11 14:27:06', 'شاورما،فحم'),
(31, 25, 'لحم بعجين', 'كيلو لحم بعجين خضار أو دبس رمان', 50000, 45000, '52_248067_فطائر-اللحم-بالعجين-السوري.jpg', 1, '2023-06-11 14:49:19', '2023-08-14 12:16:14', 'لحم يعجين،دبس رمان،خضار'),
(32, 26, 'قطايف', 'قطايف محشوة بالقشطة لعشاق الطعم الأصيل', 40000, NULL, '82_155300_2018-11-21.jpg', 1, '2023-07-19 23:28:34', '2023-07-19 23:28:34', 'قطايف،مهروسة،قشطة'),
(33, 27, 'لحم بعجين', 'لحم بعجين عنا .... شي على أصولو', 35000, 30000, '82_749602_2018-11-15.jpg', 1, '2023-07-19 23:32:11', '2023-07-19 23:32:11', 'لحم بعجين،صفيحة'),
(34, 28, 'بروستد', 'فروجة ونص بروستد ب 44 الف فقط', 50000, 44000, '81_501054_tiktakبروستدn.jpg', 1, '2023-07-19 23:42:48', '2023-07-19 23:42:48', ''),
(35, 29, 'سودة دجاج', 'وجبة سودة دجاج', 20000, 19000, '83_607113_s,]mn.jpg', 1, '2023-07-19 23:58:39', '2023-07-19 23:58:39', 'سودة');

-- --------------------------------------------------------

--
-- Table structure for table `recipe_reviews`
--

CREATE TABLE `recipe_reviews` (
  `id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `review` varchar(255) NOT NULL,
  `rate` tinyint(1) NOT NULL,
  `added_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recipe_reviews`
--

INSERT INTO `recipe_reviews` (`id`, `recipe_id`, `customer_id`, `review`, `rate`, `added_at`) VALUES
(1, 3, 1, 'الطعم بجنن الله يباركلكن ويرزقكن', 3, '2023-05-27 21:26:32'),
(2, 2, 31, 'أطيب برغر لحمة بحلب', 5, '2023-05-31 16:56:44'),
(3, 3, 23, '', 4, '2023-05-31 17:16:37'),
(4, 33, 29, '', 4, '2023-07-19 23:37:44'),
(6, 32, 25, 'أطيب من هيك ماضل', 5, '2023-07-19 23:38:28'),
(7, 32, 30, 'شي طيب', 4, '2023-07-19 23:38:57'),
(8, 32, 31, '', 5, '2023-07-19 23:39:17'),
(9, 33, 24, '', 2, '2023-07-19 23:39:39'),
(10, 21, 28, '', 4, '2023-07-19 23:40:15'),
(11, 29, 1, 'لذيذ', 4, '2023-08-11 20:21:20'),
(12, 22, 1, 'لذيذة', 4, '2023-08-13 12:17:32'),
(14, 28, 1, 'لذيذ 5', 5, '2023-08-17 09:25:29'),
(15, 28, 25, 'ولا أطيب بس غالية كتير', 4, '2023-08-16 12:26:45'),
(16, 28, 33, 'مذاق رائق سعر مناسب ووجبة شهية', 4, '2023-08-16 12:26:45'),
(18, 32, 1, 'لذيذ', 4, '2023-08-22 11:54:34');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` char(10) NOT NULL,
  `guests_num` int(11) NOT NULL,
  `reserv_date` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `notes` varchar(300) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id`, `customer_id`, `restaurant_id`, `name`, `phone`, `guests_num`, `reserv_date`, `status`, `notes`, `created_at`) VALUES
(13, 24, 49, 'Ahmed', '0992345678', 2, '2023-07-10 21:22:00', 1, '', '2023-07-09 21:22:22'),
(16, 1, 72, 'Ahmed Mohsen', '0991234567', 2, '2023-08-07 00:00:00', 3, '', '2023-08-05 00:00:00'),
(17, 36, 72, 'Zaid Homsi', '0991234567', 3, '2023-08-01 22:42:00', 4, '', '2023-08-03 00:00:00'),
(18, 38, 72, 'Asmaa Ali', '0991234567', 3, '2023-05-02 00:00:00', 4, '', '2023-05-10 00:00:00'),
(19, 38, 72, 'Asmaa Ali', '0991234567', 2, '2023-07-05 21:45:00', 2, '', '2023-07-04 21:45:23'),
(20, 38, 72, 'Asmaa Ali', '0991234567', 4, '2023-05-17 21:46:00', 4, '', '2023-05-23 21:46:45'),
(21, 38, 72, 'Asmaa Ali', '0991234567', 2, '2023-04-05 21:52:00', 4, '', '2023-04-09 21:53:09'),
(23, 1, 72, 'Ahmed Mohsen', '0991234567', 2, '2023-09-08 13:14:00', 1, '', '2023-08-14 13:14:52'),
(24, 1, 82, 'Ahmed Mohsen', '0991234567', 2, '2023-08-22 13:24:00', 1, '', '2023-08-16 13:25:03'),
(25, 1, 72, 'Ahmed Mohsen', '0991234567', 6, '2023-08-24 15:28:00', 1, '66', '2023-08-16 15:28:59'),
(26, 1, 72, 'Ahmed Mohsen', '0991234567', 3, '2023-08-18 09:29:00', 1, '', '2023-08-17 09:29:39'),
(27, 1, 72, 'Ahmed Mohsen', '0991234567', 5, '2023-08-23 12:06:00', 1, '', '2023-08-22 12:06:59');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_item`
--

CREATE TABLE `reservation_item` (
  `id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation_item`
--

INSERT INTO `reservation_item` (`id`, `reservation_id`, `recipe_id`, `quantity`) VALUES
(20, 17, 27, 2),
(21, 18, 26, 1),
(26, 23, 27, 1),
(27, 23, 9, 2),
(28, 24, 32, 1),
(29, 25, 9, 1),
(30, 25, 27, 1),
(31, 25, 25, 1),
(32, 25, 28, 1),
(33, 26, 9, 1),
(34, 27, 27, 1),
(35, 27, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reservation_status`
--

CREATE TABLE `reservation_status` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation_status`
--

INSERT INTO `reservation_status` (`id`, `status`) VALUES
(1, 'معلق'),
(2, 'مرفوض'),
(3, 'مؤكد'),
(4, 'منقضي'),
(5, 'ملغي');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `phone` char(10) NOT NULL,
  `password` varchar(150) NOT NULL,
  `description` varchar(200) NOT NULL,
  `open_time` time NOT NULL,
  `close_time` time NOT NULL,
  `delivery_service` tinyint(1) NOT NULL,
  `reserv_service` tinyint(1) NOT NULL,
  `fast_food` tinyint(1) NOT NULL,
  `profile_image` varchar(200) NOT NULL,
  `cover_image` varchar(200) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `account_status` tinyint(1) NOT NULL DEFAULT 0,
  `verify_token` varchar(60) NOT NULL,
  `authentication_files` text NOT NULL,
  `delivary_fee` int(11) DEFAULT 5000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`id`, `name`, `email`, `phone`, `password`, `description`, `open_time`, `close_time`, `delivery_service`, `reserv_service`, `fast_food`, `profile_image`, `cover_image`, `created_at`, `account_status`, `verify_token`, `authentication_files`, `delivary_fee`) VALUES
(1, 'مجمع العراب', 'arrab@gmail.com', '0992345678', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'شاورما،مأكولات غربية،فطائر', '11:00:00', '12:00:00', 0, 0, 0, '1_991249_العراب شعارn.jpg', '1_278606_العرابn.jpg', '2023-02-26 00:00:00', 2, '', '', 5000),
(28, 'الزعيم', 'zaeem@gmail.com', '0997735597', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', '11:00:00', '23:40:00', 0, 1, 0, '', '', '2023-03-28 00:00:00', 0, 'd1029a36f97d3bf576de45dcc3310950', '[{\"name\":\"3d-plastic-people-fastfood-set.png\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/28\\/3d-plastic-people-fastfood-set.png\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/28\\/3d-plastic-people-fastfood-set.png\"},{\"name\":\"Project Tasks.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/28\\/Project Tasks.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"},{\"name\":\"RestauratnsSystemERD.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/28\\/RestauratnsSystemERD.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000),
(30, 'resto', 'resto@gmail.com', '0997735597', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', '10:00:00', '22:49:00', 0, 0, 0, '', '', '2023-04-01 00:00:00', 1, 'b08db426cfe9cafe709cd870bfa6dc81', '[{\"name\":\"\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/30\\/\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000),
(49, 'القمة', 'top@gmail.com', '0933456789', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'مطعم متميز بالمشاوي و الاكلات الحلبية الاصيلة... الأكل الحلبي على أصوله ', '10:00:00', '23:00:00', 1, 0, 0, '49_602054_manufacturers-m-7189-m-7188-109.jpg', '49_640234_302426105_543665900894387_6532020143638308365_n.jpg', '2023-04-11 00:00:00', 2, '', '', 5000),
(50, 'فلافلنا', 'flafel@gmail.com', '0933456789', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', '11:00:00', '23:00:00', 1, 0, 1, '', '', '2023-04-11 00:00:00', 2, '', '', 5000),
(51, 'مجمع زكور بركات', 'barakat@gmail.com', '0953456789', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'فروج مشوي ,, بروستد ,, مسحب ,, مفخر ,, كبب ,, اكلات غربية ,, سمك ,, المشاوي باانواعها.', '11:00:00', '23:00:00', 1, 0, 1, '51_766107_زكورn.jpg', '', '2023-04-11 00:00:00', 2, '', '', 5000),
(52, 'مخبز النقار', 'nakkar@gmail.com', '0933456789', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'خبرة فنية واسعة بصناعة اللحم بعجين', '11:00:00', '23:00:00', 0, 0, 1, '52_33777_download.jpg', '52_147454_338339065_776205770505766_8523066759422031689_n.jpg', '2023-04-11 00:00:00', 2, '', '', 5000),
(53, 'شتورة', 'shtora@gmail.com', '0963456789', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '', '11:00:00', '23:00:00', 1, 0, 1, '', '', '2023-04-11 00:00:00', 2, '', '', 5000),
(72, 'الزعيم تشكن', 'zaeem2000@gmail.com', '0992345678', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'زعيم تشيكن... أول مطعم في حلب يقدم وجبات و مأكولات بتوابل و نكهات مميزة ...لك التجربة..', '10:30:00', '23:00:00', 1, 1, 0, '72_529342_zaeem.jpg', '72_34602_phoimg31.jpg', '2023-04-24 11:42:47', 2, '61d844c92c9b43459504fdcd0d66b471', '[{\"name\":\"water bill1.jpg\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/72\\/water bill1.jpg\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"},{\"name\":\"\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/72\\/\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000),
(81, 'tiktak', 'tiktak@gmail.com', '0992346789', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'تيك تاك مطعم ومقهى مميّز بأجواء حيوية وديكورات عصرية وخدمة أكثر من رائعة..!', '11:00:00', '23:00:00', 1, 0, 0, '81_374084_tiktak.jpg', '81_348512_tiktak2.jpg', '2023-07-19 22:33:35', 2, 'd5d00433899711aebc262befc62aa63d', '[{\"name\":\"water bill.png\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/81\\/water bill.png\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/81\\/water bill.png\"}]', 5000),
(82, 'مهروسة - Mahrosah', 'mahrosah@gmail.com', '0932546879', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'من حلب جينا .. والحلو أصله عنا', '11:00:00', '23:30:00', 1, 1, 0, '82_161263_2018-09-18.jpg', '82_820606_مهروسة مطعمn.jpg', '2023-07-19 23:07:18', 2, 'ae6be09eb481b43115a1f677b4eb69e0', '[{\"name\":\"water bill1.jpg\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/82\\/water bill1.jpg\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/82\\/water bill1.jpg\"},{\"name\":\"\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/82\\/\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000),
(83, 'نانرج الشام', 'naranj@gmail.com', '0984951721', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'ألذ المشويات من قلب البيئة الشامية الأصيلة لحم نعيمي طازج ذبح يومي', '11:00:00', '22:00:00', 0, 0, 0, '83_826914_نارنج شعارn.jpg', '83_144369_نارنج n.jpg', '2023-07-19 23:55:17', 2, '49690bbe41c5c6b2720e5dbaa27f43d4', '[{\"name\":\"water bill.png\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/83\\/water bill.png\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/83\\/water bill.png\"}]', 5000),
(89, 'hudifv', 'hi@gmail.com', '0995956565', '74d52ac48d721bf737d99d414389683c7e87eadd', '', '16:38:00', '17:39:00', 0, 0, 1, '', '', '2023-07-30 12:40:14', 1, 'f34149a5ae03bd46487805fea7198d53', '[{\"name\":\"water bill1.jpg\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/89\\/water bill1.jpg\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/89\\/water bill1.jpg\"},{\"name\":\"\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/89\\/\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000),
(90, 'test', 'test@gmail.com', '0935555555', '464ee44551f85282acbed24b114a73cd1966ec6d', '', '10:06:00', '21:06:00', 1, 0, 1, '', '', '2023-07-30 15:12:06', 0, '15f5a1b02d116b3d20340c88067e0b07', '[{\"name\":\"water bill1.jpg\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/90\\/water bill1.jpg\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/90\\/water bill1.jpg\"},{\"name\":\"\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/90\\/\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000),
(95, 'Zaeem Chincken', 'zaeemchicken27@gmail.com', '0997735597', '464ee44551f85282acbed24b114a73cd1966ec6d', '', '10:30:00', '11:30:00', 1, 1, 0, '', '', '2023-08-17 09:48:59', 2, '597abe396ea5bb27968ea006bc9c927c', '[{\"name\":\"water bill.jpg\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/95\\/water bill.jpg\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/95\\/water bill.jpg\"},{\"name\":\"\\u062a\\u0631\\u062e\\u064a\\u0635.jpg\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/95\\/\\u062a\\u0631\\u062e\\u064a\\u0635.jpg\",\"altPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/95\\/\\u062a\\u0631\\u062e\\u064a\\u0635.jpg\"},{\"name\":\"\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"relPath\":\"\\/5thProject\\/admin\\/uploads\\/authentication_files\\/95\\/\\u0639\\u0642\\u062f \\u0623\\u062c\\u0627\\u0631.pdf\",\"altPath\":\"\\/5thProject\\/admin\\/layout\\/images\\/Standard\\/pdf.svg\"}]', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_reviews`
--

CREATE TABLE `restaurant_reviews` (
  `id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `review` varchar(255) NOT NULL,
  `rate` tinyint(1) NOT NULL,
  `added_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurant_reviews`
--

INSERT INTO `restaurant_reviews` (`id`, `restaurant_id`, `customer_id`, `review`, `rate`, `added_at`) VALUES
(2, 72, 29, 'not bad', 3, '2023-06-22 15:51:47'),
(3, 72, 24, 'رائع ..!', 4, '2023-06-23 15:32:38'),
(4, 49, 27, 'القمة نعم الاختيار', 4, '2023-07-02 10:43:05'),
(5, 52, 31, '', 5, '2023-07-02 10:43:23'),
(6, 52, 29, 'أطيب لحم بعجين', 4, '2023-07-02 10:44:26'),
(7, 49, 25, '', 3, '2023-07-02 10:45:09'),
(8, 51, 26, 'أفضل مجمع في حلب', 5, '2023-07-02 13:06:19'),
(9, 81, 27, 'رائع..!', 4, '2023-07-19 23:13:58'),
(10, 82, 27, 'رائع..!', 5, '2023-07-19 23:14:46'),
(11, 81, 31, '', 3, '2023-07-19 23:15:16'),
(12, 82, 31, '', 4, '2023-07-19 23:15:32'),
(13, 81, 26, 'لا يعلى عليه، بس آخر فترة الأسعار ارتفعت  زيادة', 3, '2023-07-19 23:16:31'),
(14, 82, 26, '', 4, '2023-07-19 23:17:14'),
(15, 52, 25, 'رقم واحد بسوريا..', 5, '2023-07-19 23:18:18'),
(16, 81, 24, '', 2, '2023-07-19 23:18:44'),
(17, 82, 24, '', 3, '2023-07-19 23:18:58'),
(18, 51, 28, '', 4, '2023-07-19 23:19:35'),
(19, 82, 30, 'رقم واحد للحلو الأصلي العريق', 5, '2023-07-19 23:20:37'),
(20, 83, 24, '', 5, '2023-07-20 00:00:20'),
(21, 83, 26, '', 4, '2023-07-20 00:00:20'),
(22, 83, 27, 'رائع..!', 5, '2023-07-20 00:00:20'),
(23, 83, 31, '', 3, '2023-07-20 00:00:20'),
(24, 1, 30, '', 4, '2023-07-20 00:02:43'),
(25, 82, 1, '', 5, '2023-07-30 13:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`) VALUES
(1, 'دمشق'),
(2, 'ريف دمشق'),
(3, 'حلب'),
(4, 'حماة'),
(5, 'حمص'),
(6, 'اللاذقية'),
(7, 'طرطوس'),
(8, 'ديرالزور'),
(9, 'الرقة'),
(10, 'الحسكة'),
(11, 'إدلب'),
(12, 'السويداء'),
(13, 'القنيطرة'),
(14, 'درعا');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `restaurant_address` (`restaurant_id`),
  ADD KEY `address_state` (`state`);

--
-- Indexes for table `advert`
--
ALTER TABLE `advert`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Restaurant_Advert` (`restaurant_id`),
  ADD KEY `Advert_Type` (`ad_type`);

--
-- Indexes for table `ad_comment`
--
ALTER TABLE `ad_comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Advert_Comment` (`advert_id`),
  ADD KEY `Customer_Comment` (`customer_id`);

--
-- Indexes for table `ad_react`
--
ALTER TABLE `ad_react`
  ADD PRIMARY KEY (`id`),
  ADD KEY `React_Type` (`react_id`),
  ADD KEY `Advert_React` (`advert_id`),
  ADD KEY `Customer_React` (`customer_id`);

--
-- Indexes for table `ad_type`
--
ALTER TABLE `ad_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Cart_Cusomer` (`customer_id`),
  ADD KEY `Cart_Recipe` (`recipe_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Restaurant_Menu` (`restaurant_id`);

--
-- Indexes for table `order_`
--
ALTER TABLE `order_`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Customer_Order` (`customer_id`),
  ADD KEY `Order_Status` (`order_status`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Order_Item` (`order_id`),
  ADD KEY `Order_Recipe` (`recipe_id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `react`
--
ALTER TABLE `react`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recipe`
--
ALTER TABLE `recipe`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Menu_Recipe` (`menu_id`);

--
-- Indexes for table `recipe_reviews`
--
ALTER TABLE `recipe_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Customer_Review` (`customer_id`),
  ADD KEY `Recipe_Review` (`recipe_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Restaurant_Reservation` (`restaurant_id`),
  ADD KEY `Customer_Reservation` (`customer_id`),
  ADD KEY `Reservation_Status` (`status`);

--
-- Indexes for table `reservation_item`
--
ALTER TABLE `reservation_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Reservation_Recipe` (`recipe_id`),
  ADD KEY `Reservation_Item` (`reservation_id`);

--
-- Indexes for table `reservation_status`
--
ALTER TABLE `reservation_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant_reviews`
--
ALTER TABLE `restaurant_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Restarant_Review` (`restaurant_id`),
  ADD KEY `Customer__Rest_Review` (`customer_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `advert`
--
ALTER TABLE `advert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `ad_comment`
--
ALTER TABLE `ad_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `ad_react`
--
ALTER TABLE `ad_react`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `ad_type`
--
ALTER TABLE `ad_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `order_`
--
ALTER TABLE `order_`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `react`
--
ALTER TABLE `react`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `recipe`
--
ALTER TABLE `recipe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `recipe_reviews`
--
ALTER TABLE `recipe_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `reservation_item`
--
ALTER TABLE `reservation_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `reservation_status`
--
ALTER TABLE `reservation_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `restaurant_reviews`
--
ALTER TABLE `restaurant_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_state` FOREIGN KEY (`state`) REFERENCES `state` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `restaurant_address` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `advert`
--
ALTER TABLE `advert`
  ADD CONSTRAINT `Advert_Type` FOREIGN KEY (`ad_type`) REFERENCES `ad_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Restaurant_Advert` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ad_comment`
--
ALTER TABLE `ad_comment`
  ADD CONSTRAINT `Advert_Comment` FOREIGN KEY (`advert_id`) REFERENCES `advert` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Customer_Comment` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ad_react`
--
ALTER TABLE `ad_react`
  ADD CONSTRAINT `Advert_React` FOREIGN KEY (`advert_id`) REFERENCES `advert` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Customer_React` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `React_Type` FOREIGN KEY (`react_id`) REFERENCES `react` (`id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `Cart_Cusomer` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Cart_Recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipe` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `Restaurant_Menu` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_`
--
ALTER TABLE `order_`
  ADD CONSTRAINT `Customer_Order` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Order_Status` FOREIGN KEY (`order_status`) REFERENCES `order_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `Order_Item` FOREIGN KEY (`order_id`) REFERENCES `order_` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Order_Recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipe` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `recipe`
--
ALTER TABLE `recipe`
  ADD CONSTRAINT `Menu_Recipe` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `recipe_reviews`
--
ALTER TABLE `recipe_reviews`
  ADD CONSTRAINT `Customer_Review` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Recipe_Review` FOREIGN KEY (`recipe_id`) REFERENCES `recipe` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `Customer_Reservation` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Reservation_Status` FOREIGN KEY (`status`) REFERENCES `reservation_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Restaurant_Reservation` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservation_item`
--
ALTER TABLE `reservation_item`
  ADD CONSTRAINT `Reservation_Item` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Reservation_Recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipe` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `restaurant_reviews`
--
ALTER TABLE `restaurant_reviews`
  ADD CONSTRAINT `Customer__Rest_Review` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Restarant_Review` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
